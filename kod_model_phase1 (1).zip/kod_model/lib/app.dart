import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'features/models/presentation/home_screen.dart';

class KodModelApp extends StatelessWidget {
  const KodModelApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'تكويد الموديلات',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar', 'EG'),
      supportedLocales: const [Locale('ar', 'EG'), Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF1F6F6B),
        visualDensity: VisualDensity.standard,
      ),
      home: const HomeScreen(),
    );
  }
}
