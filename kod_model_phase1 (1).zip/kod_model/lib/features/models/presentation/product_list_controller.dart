import 'package:flutter/foundation.dart';

import '../data/product_repository.dart';
import '../domain/product.dart';

class ProductListController extends ChangeNotifier {
  ProductListController(this._repo);
  final ProductRepository _repo;

  List<Product> products = const [];
  bool loading = true;
  String? error;
  String query = '';
  ProductSort sort = ProductSort.recent;
  int _seq = 0; // ignore out-of-order results

  Future<void> load() async {
    final my = ++_seq;
    loading = true;
    error = null;
    notifyListeners();
    try {
      final result = await _repo.list(query: query, sort: sort);
      if (my != _seq) return;
      products = result;
    } catch (_) {
      if (my != _seq) return;
      error = 'مقدرناش نفتح الموديلات. جرب تاني.';
    }
    loading = false;
    notifyListeners();
  }

  void setQuery(String q) {
    query = q;
    load();
  }

  void setSort(ProductSort s) {
    sort = s;
    load();
  }
}
