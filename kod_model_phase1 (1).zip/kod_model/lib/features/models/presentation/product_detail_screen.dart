import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/code_utils.dart';
import '../../../core/photo_service.dart';
import '../data/product_repository.dart';
import '../domain/product.dart';
import 'product_form_screen.dart';

class ProductDetailScreen extends StatefulWidget {
  const ProductDetailScreen({super.key, required this.productId});
  final String productId;

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  Product? _product;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final p = await context.read<ProductRepository>().getById(widget.productId);
    if (!mounted) return;
    setState(() {
      _product = p;
      _loading = false;
    });
  }

  Future<void> _edit() async {
    await Navigator.of(context).push<bool>(
      MaterialPageRoute(
          builder: (_) => ProductFormScreen(existing: _product)),
    );
    if (mounted) _reload();
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف الموديل؟'),
        content: Text('هتحذف "${_product!.name}". متأكد؟'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('احذف')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    await context.read<ProductRepository>().softDelete(widget.productId);
    if (mounted) Navigator.of(context).pop();
  }

  void _zoom(String fileName) {
    showDialog<void>(
      context: context,
      builder: (_) => Dialog(
        insetPadding: const EdgeInsets.all(8),
        child: InteractiveViewer(
          child: PhotoImage(fileName: fileName, fit: BoxFit.contain),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = _product;
    return Scaffold(
      appBar: AppBar(
        title: Text(p?.name ?? 'الموديل'),
        actions: p == null
            ? null
            : [
                IconButton(
                    tooltip: 'تعديل',
                    icon: const Icon(Icons.edit_outlined),
                    onPressed: _edit),
                IconButton(
                    tooltip: 'حذف',
                    icon: const Icon(Icons.delete_outline),
                    onPressed: _delete),
              ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : p == null
              ? const Center(child: Text('الموديل ده مش موجود.'))
              : _content(p),
    );
  }

  Widget _content(Product p) {
    final price = formatPrice(p.price, p.currency);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (p.mainPhoto != null)
          GestureDetector(
            onTap: () => _zoom(p.mainPhoto!),
            child: AspectRatio(
              aspectRatio: 4 / 3,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: PhotoImage(fileName: p.mainPhoto!),
              ),
            ),
          ),
        if (p.extraPhotos.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: SizedBox(
              height: 84,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  for (final n in p.extraPhotos)
                    Padding(
                      padding: const EdgeInsetsDirectional.only(end: 8),
                      child: GestureDetector(
                        onTap: () => _zoom(n),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: PhotoImage(
                              fileName: n, width: 84, height: 84, cacheWidth: 250),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        const SizedBox(height: 16),
        _row('الكود', p.code),
        _row('الاسم', p.name),
        if (price != null) _row('السعر', price),
        if (p.fabric.isNotEmpty) _row('القماش / الخامة', p.fabric),
        if (p.sizes.isNotEmpty) _chips('المقاسات', p.sizes),
        if (p.colors.isNotEmpty) _chips('الألوان', p.colors),
        if (p.description.isNotEmpty) _row('الوصف / ملاحظات', p.description),
        if (p.extraDetails.isNotEmpty) _row('تفاصيل إضافية', p.extraDetails),
        _row('أُنشئ في', formatDate(p.createdAt)),
        _row('آخر تعديل', formatDate(p.updatedAt)),
      ],
    );
  }

  Widget _row(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label,
                style: Theme.of(context)
                    .textTheme
                    .labelMedium
                    ?.copyWith(color: Theme.of(context).hintColor)),
            const SizedBox(height: 2),
            Text(value, style: Theme.of(context).textTheme.bodyLarge),
          ],
        ),
      );

  Widget _chips(String label, List<String> values) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label,
                style: Theme.of(context)
                    .textTheme
                    .labelMedium
                    ?.copyWith(color: Theme.of(context).hintColor)),
            const SizedBox(height: 4),
            Wrap(spacing: 8, children: [
              for (final v in values) Chip(label: Text(v)),
            ]),
          ],
        ),
      );
}
