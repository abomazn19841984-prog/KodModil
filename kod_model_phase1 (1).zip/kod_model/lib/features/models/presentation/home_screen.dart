import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/code_utils.dart';
import '../../../core/photo_service.dart';
import '../data/product_repository.dart';
import '../domain/product.dart';
import 'product_detail_screen.dart';
import 'product_form_screen.dart';
import 'product_list_controller.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _searchC = TextEditingController();

  @override
  void dispose() {
    _searchC.dispose();
    super.dispose();
  }

  Future<void> _add() async {
    await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => const ProductFormScreen()),
    );
    if (mounted) context.read<ProductListController>().load();
  }

  Future<void> _open(Product p) async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute(builder: (_) => ProductDetailScreen(productId: p.id)),
    );
    if (mounted) context.read<ProductListController>().load();
  }

  @override
  Widget build(BuildContext context) {
    final c = context.watch<ProductListController>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('تكويد الموديلات'),
        actions: [
          PopupMenuButton<ProductSort>(
            tooltip: 'ترتيب',
            icon: const Icon(Icons.sort),
            initialValue: c.sort,
            onSelected: c.setSort,
            itemBuilder: (_) => const [
              PopupMenuItem(
                  value: ProductSort.recent, child: Text('الأحدث تعديلًا')),
              PopupMenuItem(value: ProductSort.code, child: Text('بالكود')),
              PopupMenuItem(value: ProductSort.name, child: Text('بالاسم')),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
            child: TextField(
              controller: _searchC,
              onChanged: c.setQuery,
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: 'ابحث بالكود أو اسم الموديل',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchC.text.isEmpty
                    ? null
                    : IconButton(
                        tooltip: 'مسح',
                        icon: const Icon(Icons.close),
                        onPressed: () {
                          _searchC.clear();
                          c.setQuery('');
                          setState(() {});
                        },
                      ),
                border: const OutlineInputBorder(),
                isDense: true,
              ),
            ),
          ),
          Expanded(child: _body(c)),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _add,
        icon: const Icon(Icons.add),
        label: const Text('موديل جديد'),
      ),
    );
  }

  Widget _body(ProductListController c) {
    if (c.loading && c.products.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    if (c.error != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(c.error!),
            const SizedBox(height: 12),
            FilledButton(onPressed: c.load, child: const Text('حاول تاني')),
          ],
        ),
      );
    }
    if (c.products.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            c.query.trim().isEmpty
                ? 'لسه مفيش موديلات.\nدوس "موديل جديد" وابدأ.'
                : 'مفيش نتايج للبحث ده.',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.titleMedium,
          ),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(8, 4, 8, 96),
      itemCount: c.products.length,
      itemBuilder: (_, i) {
        final p = c.products[i];
        return _ProductTile(product: p, onTap: () => _open(p));
      },
    );
  }
}

class _ProductTile extends StatelessWidget {
  const _ProductTile({required this.product, required this.onTap});
  final Product product;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final price = formatPrice(product.price, product.currency);
    return Card(
      child: ListTile(
        onTap: onTap,
        minVerticalPadding: 10,
        leading: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: SizedBox(
            width: 56,
            height: 56,
            child: product.mainPhoto == null
                ? const ColoredBox(
                    color: Color(0xFFE8EEEE),
                    child: Icon(Icons.checkroom_outlined),
                  )
                : PhotoImage(fileName: product.mainPhoto!, cacheWidth: 168),
          ),
        ),
        title: Text(product.name, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Text('كود: ${product.code}'),
        trailing: price == null ? null : Text(price),
      ),
    );
  }
}
