import 'package:flutter/material.dart';

/// Small multi-value input (used for sizes and colors).
class TagsInput extends StatefulWidget {
  const TagsInput({
    super.key,
    required this.label,
    required this.hint,
    required this.values,
    required this.onChanged,
  });

  final String label;
  final String hint;
  final List<String> values;
  final ValueChanged<List<String>> onChanged;

  @override
  State<TagsInput> createState() => _TagsInputState();
}

class _TagsInputState extends State<TagsInput> {
  final _c = TextEditingController();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  void _add() {
    final t = _c.text.trim();
    if (t.isEmpty) return;
    final exists =
        widget.values.any((v) => v.toLowerCase() == t.toLowerCase());
    if (!exists) widget.onChanged([...widget.values, t]);
    _c.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextField(
          controller: _c,
          textInputAction: TextInputAction.done,
          onSubmitted: (_) => _add(),
          decoration: InputDecoration(
            labelText: widget.label,
            hintText: widget.hint,
            border: const OutlineInputBorder(),
            suffixIcon: IconButton(
              tooltip: 'إضافة',
              icon: const Icon(Icons.add_circle_outline),
              onPressed: _add,
            ),
          ),
        ),
        if (widget.values.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                for (final v in widget.values)
                  InputChip(
                    label: Text(v),
                    onDeleted: () => widget
                        .onChanged(widget.values.where((e) => e != v).toList()),
                  ),
              ],
            ),
          ),
      ],
    );
  }
}
