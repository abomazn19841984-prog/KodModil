import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../../core/code_utils.dart';
import '../../../core/photo_service.dart';
import '../data/product_repository.dart';
import '../domain/product.dart';
import 'tags_input.dart';

/// Add (existing == null) or edit a model.
class ProductFormScreen extends StatefulWidget {
  const ProductFormScreen({super.key, this.existing});
  final Product? existing;

  @override
  State<ProductFormScreen> createState() => _ProductFormScreenState();
}

class _ProductFormScreenState extends State<ProductFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _codeC;
  late final TextEditingController _nameC;
  late final TextEditingController _priceC;
  late final TextEditingController _fabricC;
  late final TextEditingController _descC;
  late final TextEditingController _extraC;
  late List<String> _sizes;
  late List<String> _colors;
  String? _mainPhoto;
  late List<String> _extraPhotos;
  late final PhotoService _photos;

  /// Photos picked during this session (deleted if the user does not save).
  final Set<String> _added = {};
  String? _codeError;
  bool _saving = false;
  bool _saved = false;

  @override
  void initState() {
    super.initState();
    _photos = context.read<PhotoService>();
    final e = widget.existing;
    _codeC = TextEditingController(text: e?.code ?? '');
    _nameC = TextEditingController(text: e?.name ?? '');
    _priceC = TextEditingController(
        text: e?.price == null ? '' : formatPrice(e!.price, '')!.trim());
    _fabricC = TextEditingController(text: e?.fabric ?? '');
    _descC = TextEditingController(text: e?.description ?? '');
    _extraC = TextEditingController(text: e?.extraDetails ?? '');
    _sizes = [...?e?.sizes];
    _colors = [...?e?.colors];
    _mainPhoto = e?.mainPhoto;
    _extraPhotos = [...?e?.extraPhotos];
  }

  @override
  void dispose() {
    if (!_saved) {
      for (final n in _added) {
        _photos.delete(n);
      }
    }
    _codeC.dispose();
    _nameC.dispose();
    _priceC.dispose();
    _fabricC.dispose();
    _descC.dispose();
    _extraC.dispose();
    super.dispose();
  }

  Future<void> _pick({required bool main}) async {
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera_outlined),
              title: const Text('تصوير بالكاميرا'),
              onTap: () => Navigator.pop(ctx, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: const Text('اختيار من المعرض'),
              onTap: () => Navigator.pop(ctx, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (source == null) return;
    try {
      final name = await _photos.pick(source);
      if (name == null || !mounted) return;
      _added.add(name);
      setState(() {
        if (main) {
          _mainPhoto = name;
        } else {
          _extraPhotos.add(name);
        }
      });
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('مقدرناش نفتح الكاميرا أو المعرض. اتأكد من الصلاحيات.'),
      ));
    }
  }

  Future<void> _save() async {
    setState(() => _codeError = null);
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    final repo = context.read<ProductRepository>();
    final old = widget.existing;
    final now = DateTime.now().toUtc();
    final code = _codeC.text.trim();
    final product = Product(
      id: old?.id ?? generateId(),
      ownerUid: old?.ownerUid,
      code: code,
      codeKey: normalizeCode(code),
      name: _nameC.text.trim(),
      description: _descC.text.trim(),
      price: parsePrice(_priceC.text),
      currency: old?.currency ?? Product.defaultCurrency,
      fabric: _fabricC.text.trim(),
      sizes: _sizes,
      colors: _colors,
      extraDetails: _extraC.text.trim(),
      mainPhoto: _mainPhoto,
      extraPhotos: _extraPhotos,
      createdAt: old?.createdAt ?? now,
      updatedAt: now,
      version: old?.version ?? 1,
    );
    try {
      if (old == null) {
        await repo.create(product);
      } else {
        await repo.update(product);
      }
    } on DuplicateCodeException {
      if (!mounted) return;
      setState(() {
        _saving = false;
        _codeError = 'الكود ده مستخدم قبل كده في موديل تاني';
      });
      _formKey.currentState!.validate();
      return;
    } catch (_) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('حصلت مشكلة وإحنا بنحفظ. بياناتك لسه قدامك، جرب تاني.'),
      ));
      return;
    }
    // Saved: delete photo files that are no longer used.
    final keep = product.allPhotos.toSet();
    final candidates = {...?old?.allPhotos, ..._added};
    for (final n in candidates.difference(keep)) {
      await _photos.delete(n);
    }
    _saved = true;
    if (mounted) Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.existing != null;
    return Scaffold(
      appBar: AppBar(title: Text(editing ? 'تعديل الموديل' : 'موديل جديد')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _photoSection(),
            const SizedBox(height: 16),
            TextFormField(
              controller: _codeC,
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(
                  labelText: 'كود الموديل *', border: OutlineInputBorder()),
              validator: (v) => _codeError ?? ProductValidator.code(v ?? ''),
              onChanged: (_) {
                if (_codeError != null) setState(() => _codeError = null);
              },
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _nameC,
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(
                  labelText: 'اسم الموديل *', border: OutlineInputBorder()),
              validator: (v) => ProductValidator.name(v ?? ''),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _priceC,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              textInputAction: TextInputAction.next,
              decoration: InputDecoration(
                labelText: 'السعر (اختياري)',
                suffixText: widget.existing?.currency ?? Product.defaultCurrency,
                border: const OutlineInputBorder(),
              ),
              validator: (v) => ProductValidator.price(v ?? ''),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _fabricC,
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(
                  labelText: 'القماش / الخامة (اختياري)',
                  border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TagsInput(
              label: 'المقاسات',
              hint: 'مثال: M ثم اضغط +',
              values: _sizes,
              onChanged: (v) => setState(() => _sizes = v),
            ),
            const SizedBox(height: 12),
            TagsInput(
              label: 'الألوان',
              hint: 'مثال: أسود ثم اضغط +',
              values: _colors,
              onChanged: (v) => setState(() => _colors = v),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _descC,
              minLines: 2,
              maxLines: 5,
              decoration: const InputDecoration(
                  labelText: 'الوصف / ملاحظات', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _extraC,
              minLines: 2,
              maxLines: 5,
              decoration: const InputDecoration(
                  labelText: 'تفاصيل إضافية', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _saving ? null : _save,
              icon: _saving
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.check),
              label: const Text('حفظ'),
              style: FilledButton.styleFrom(minimumSize: const Size(0, 52)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _photoSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('الصورة الرئيسية',
            style: Theme.of(context).textTheme.titleSmall),
        const SizedBox(height: 8),
        InkWell(
          onTap: () => _pick(main: true),
          child: Container(
            height: 180,
            width: double.infinity,
            decoration: BoxDecoration(
              border: Border.all(color: Theme.of(context).dividerColor),
              borderRadius: BorderRadius.circular(8),
            ),
            child: _mainPhoto == null
                ? const Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.add_a_photo_outlined, size: 36),
                        SizedBox(height: 6),
                        Text('أضف صورة'),
                      ],
                    ),
                  )
                : Stack(
                    fit: StackFit.expand,
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: PhotoImage(fileName: _mainPhoto!),
                      ),
                      PositionedDirectional(
                        top: 4,
                        end: 4,
                        child: IconButton.filled(
                          tooltip: 'حذف الصورة',
                          icon: const Icon(Icons.close),
                          onPressed: () => setState(() => _mainPhoto = null),
                        ),
                      ),
                    ],
                  ),
          ),
        ),
        const SizedBox(height: 12),
        Text('صور إضافية (اختياري)',
            style: Theme.of(context).textTheme.titleSmall),
        const SizedBox(height: 8),
        SizedBox(
          height: 84,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              InkWell(
                onTap: () => _pick(main: false),
                child: Container(
                  width: 84,
                  decoration: BoxDecoration(
                    border: Border.all(color: Theme.of(context).dividerColor),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(Icons.add_a_photo_outlined),
                ),
              ),
              for (final n in _extraPhotos)
                Padding(
                  padding: const EdgeInsetsDirectional.only(start: 8),
                  child: SizedBox(
                    width: 84,
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: PhotoImage(fileName: n, cacheWidth: 250),
                        ),
                        PositionedDirectional(
                          top: 0,
                          end: 0,
                          child: IconButton.filled(
                            tooltip: 'حذف الصورة',
                            visualDensity: VisualDensity.compact,
                            icon: const Icon(Icons.close, size: 16),
                            onPressed: () =>
                                setState(() => _extraPhotos.remove(n)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}
