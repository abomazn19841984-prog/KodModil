import 'dart:convert';

import '../../../core/code_utils.dart';

class Product {
  const Product({
    required this.id,
    this.ownerUid,
    required this.code,
    required this.codeKey,
    required this.name,
    this.description = '',
    this.price,
    this.currency = defaultCurrency,
    this.fabric = '',
    this.sizes = const [],
    this.colors = const [],
    this.extraDetails = '',
    this.mainPhoto,
    this.extraPhotos = const [],
    required this.createdAt,
    required this.updatedAt,
    this.deletedAt,
    this.version = 1,
    this.syncState = 'pending',
  });

  static const defaultCurrency = 'جنيه مصري';

  /// Stable random ID (NOT based on the code).
  final String id;

  /// Firebase user id; null until Phase 2 (accounts).
  final String? ownerUid;
  final String code;

  /// normalizeCode(code) — used for uniqueness and search.
  final String codeKey;
  final String name;
  final String description;
  final double? price;
  final String currency;
  final String fabric;
  final List<String> sizes;
  final List<String> colors;
  final String extraDetails;

  /// Photo FILE NAMES (inside the app photos folder), not full paths.
  final String? mainPhoto;
  final List<String> extraPhotos;
  final DateTime createdAt;
  final DateTime updatedAt;

  /// Non-null = deleted (tombstone, needed for sync in Phase 3).
  final DateTime? deletedAt;
  final int version;

  /// 'pending' | 'synced' | 'failed' (sync arrives in Phase 3).
  final String syncState;

  factory Product.create({
    required String code,
    required String name,
    String description = '',
    double? price,
    String fabric = '',
    List<String> sizes = const [],
    List<String> colors = const [],
    String extraDetails = '',
    String? mainPhoto,
    List<String> extraPhotos = const [],
  }) {
    final now = DateTime.now().toUtc();
    return Product(
      id: generateId(),
      code: code.trim(),
      codeKey: normalizeCode(code),
      name: name.trim(),
      description: description,
      price: price,
      fabric: fabric,
      sizes: sizes,
      colors: colors,
      extraDetails: extraDetails,
      mainPhoto: mainPhoto,
      extraPhotos: extraPhotos,
      createdAt: now,
      updatedAt: now,
    );
  }

  List<String> get allPhotos => [
        if (mainPhoto != null) mainPhoto!,
        ...extraPhotos,
      ];

  Map<String, Object?> toMap() => {
        'id': id,
        'owner_uid': ownerUid,
        'code': code,
        'code_key': codeKey,
        'name': name,
        'description': description,
        'price': price,
        'currency': currency,
        'fabric': fabric,
        'sizes': jsonEncode(sizes),
        'colors': jsonEncode(colors),
        'extra_details': extraDetails,
        'main_photo': mainPhoto,
        'extra_photos': jsonEncode(extraPhotos),
        'created_at': createdAt.millisecondsSinceEpoch,
        'updated_at': updatedAt.millisecondsSinceEpoch,
        'deleted_at': deletedAt?.millisecondsSinceEpoch,
        'version': version,
        'sync_state': syncState,
      };

  factory Product.fromMap(Map<String, Object?> m) {
    List<String> list(Object? v) =>
        (jsonDecode(v as String) as List).map((e) => e as String).toList();
    DateTime time(Object? v) =>
        DateTime.fromMillisecondsSinceEpoch(v as int, isUtc: true);
    return Product(
      id: m['id'] as String,
      ownerUid: m['owner_uid'] as String?,
      code: m['code'] as String,
      codeKey: m['code_key'] as String,
      name: m['name'] as String,
      description: m['description'] as String,
      price: (m['price'] as num?)?.toDouble(),
      currency: m['currency'] as String,
      fabric: m['fabric'] as String,
      sizes: list(m['sizes']),
      colors: list(m['colors']),
      extraDetails: m['extra_details'] as String,
      mainPhoto: m['main_photo'] as String?,
      extraPhotos: list(m['extra_photos']),
      createdAt: time(m['created_at']),
      updatedAt: time(m['updated_at']),
      deletedAt: m['deleted_at'] == null ? null : time(m['deleted_at']),
      version: m['version'] as int,
      syncState: m['sync_state'] as String,
    );
  }
}

class ProductValidator {
  static String? code(String v) {
    final t = v.trim();
    if (t.isEmpty) return 'اكتب كود الموديل';
    if (t.length > 40) return 'الكود طويل (الحد الأقصى 40 حرف)';
    return null;
  }

  static String? name(String v) {
    final t = v.trim();
    if (t.isEmpty) return 'اكتب اسم الموديل';
    if (t.length > 80) return 'الاسم طويل (الحد الأقصى 80 حرف)';
    return null;
  }

  static String? price(String v) {
    if (v.trim().isEmpty) return null; // optional
    final p = parsePrice(v);
    if (p == null) return 'السعر لازم يكون رقم';
    if (p < 0) return 'السعر مينفعش يبقى بالسالب';
    return null;
  }
}
