import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// Local SQLite database (source of truth; works fully offline).
///
/// Migration strategy: bump [schemaVersion] and add a step inside
/// [_onUpgrade] guarded by `if (oldVersion < N)`. Never edit old steps.
class AppDatabase {
  static const int schemaVersion = 1;

  /// [path] = null uses the default app database location.
  /// Tests pass [inMemoryDatabasePath] or a temp file path.
  static Future<Database> open({String? path}) async {
    final dbPath = path ?? p.join(await getDatabasesPath(), 'kod_model.db');
    return openDatabase(
      dbPath,
      version: schemaVersion,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  static Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE products (
        id TEXT PRIMARY KEY,
        owner_uid TEXT,
        code TEXT NOT NULL,
        code_key TEXT NOT NULL,
        name TEXT NOT NULL,
        description TEXT NOT NULL DEFAULT '',
        price REAL,
        currency TEXT NOT NULL DEFAULT 'جنيه مصري',
        fabric TEXT NOT NULL DEFAULT '',
        sizes TEXT NOT NULL DEFAULT '[]',
        colors TEXT NOT NULL DEFAULT '[]',
        extra_details TEXT NOT NULL DEFAULT '',
        main_photo TEXT,
        extra_photos TEXT NOT NULL DEFAULT '[]',
        created_at INTEGER NOT NULL,
        updated_at INTEGER NOT NULL,
        deleted_at INTEGER,
        version INTEGER NOT NULL DEFAULT 1,
        sync_state TEXT NOT NULL DEFAULT 'pending'
      )
    ''');
    // Unique code per merchant among NON-deleted rows only,
    // so a code can be reused after its model is deleted.
    await db.execute('''
      CREATE UNIQUE INDEX idx_products_code_active
      ON products(code_key) WHERE deleted_at IS NULL
    ''');
    await db.execute(
        'CREATE INDEX idx_products_updated ON products(updated_at)');
  }

  static Future<void> _onUpgrade(
      Database db, int oldVersion, int newVersion) async {
    // Example for the future:
    // if (oldVersion < 2) { await db.execute('ALTER TABLE products ADD ...'); }
  }
}
