import 'package:sqflite/sqflite.dart';

import '../../../core/code_utils.dart';
import '../domain/product.dart';

enum ProductSort { recent, code, name }

class DuplicateCodeException implements Exception {
  DuplicateCodeException(this.code);
  final String code;
  @override
  String toString() => 'DuplicateCodeException($code)';
}

class ProductRepository {
  ProductRepository(this._db, {DateTime Function()? clock})
      : _clock = clock ?? DateTime.now;

  final Database _db;
  final DateTime Function() _clock;
  static const _table = 'products';

  static String _escapeLike(String s) => s
      .replaceAll('\\', '\\\\')
      .replaceAll('%', '\\%')
      .replaceAll('_', '\\_');

  /// Non-deleted products, optionally filtered by code or name.
  Future<List<Product>> list({
    String query = '',
    ProductSort sort = ProductSort.recent,
  }) async {
    final where = StringBuffer('deleted_at IS NULL');
    final args = <Object?>[];
    final q = query.trim();
    if (q.isNotEmpty) {
      where.write(
          " AND (code_key LIKE ? ESCAPE '\\' OR name LIKE ? ESCAPE '\\')");
      args
        ..add('%${_escapeLike(normalizeCode(q))}%')
        ..add('%${_escapeLike(q)}%');
    }
    final order = switch (sort) {
      ProductSort.recent => 'updated_at DESC',
      ProductSort.code => 'code_key ASC',
      ProductSort.name => 'name COLLATE NOCASE ASC',
    };
    final rows = await _db.query(
      _table,
      where: where.toString(),
      whereArgs: args,
      orderBy: order,
    );
    return rows.map(Product.fromMap).toList();
  }

  Future<Product?> getById(String id, {bool includeDeleted = false}) async {
    final rows = await _db.query(
      _table,
      where: includeDeleted ? 'id = ?' : 'id = ? AND deleted_at IS NULL',
      whereArgs: [id],
      limit: 1,
    );
    return rows.isEmpty ? null : Product.fromMap(rows.first);
  }

  Future<bool> _codeTaken(DatabaseExecutor ex, String codeKey,
      {String? excludeId}) async {
    final rows = await ex.query(
      _table,
      columns: ['id'],
      where: excludeId == null
          ? 'code_key = ? AND deleted_at IS NULL'
          : 'code_key = ? AND deleted_at IS NULL AND id != ?',
      whereArgs: excludeId == null ? [codeKey] : [codeKey, excludeId],
      limit: 1,
    );
    return rows.isNotEmpty;
  }

  Future<Product> create(Product p) async {
    try {
      await _db.transaction((txn) async {
        if (await _codeTaken(txn, p.codeKey)) {
          throw DuplicateCodeException(p.code);
        }
        await txn.insert(_table, p.toMap());
      });
    } on DatabaseException catch (e) {
      if (e.isUniqueConstraintError()) throw DuplicateCodeException(p.code);
      rethrow;
    }
    return p;
  }

  /// Saves edits: bumps version, sets updated_at, marks sync_state pending.
  Future<Product> update(Product p) async {
    final map = p.toMap()
      ..['updated_at'] = _clock().toUtc().millisecondsSinceEpoch
      ..['version'] = p.version + 1
      ..['sync_state'] = 'pending';
    try {
      await _db.transaction((txn) async {
        if (await _codeTaken(txn, p.codeKey, excludeId: p.id)) {
          throw DuplicateCodeException(p.code);
        }
        final n = await txn.update(
          _table,
          map,
          where: 'id = ? AND deleted_at IS NULL',
          whereArgs: [p.id],
        );
        if (n == 0) throw StateError('Product ${p.id} not found');
      });
    } on DatabaseException catch (e) {
      if (e.isUniqueConstraintError()) throw DuplicateCodeException(p.code);
      rethrow;
    }
    return Product.fromMap(map);
  }

  /// Soft delete (tombstone). The row stays so Phase 3 sync can tell the
  /// server it was deleted and an old server copy will not reappear.
  Future<void> softDelete(String id) async {
    final now = _clock().toUtc().millisecondsSinceEpoch;
    await _db.rawUpdate(
      'UPDATE $_table SET deleted_at = ?, updated_at = ?, '
      "version = version + 1, sync_state = 'pending' "
      'WHERE id = ? AND deleted_at IS NULL',
      [now, now, id],
    );
  }
}
