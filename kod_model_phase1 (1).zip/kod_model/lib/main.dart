import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'app.dart';
import 'core/photo_service.dart';
import 'features/models/data/app_database.dart';
import 'features/models/data/product_repository.dart';
import 'features/models/presentation/product_list_controller.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final db = await AppDatabase.open();
  final repo = ProductRepository(db);
  final photos = await PhotoService.create();
  runApp(
    MultiProvider(
      providers: [
        Provider<ProductRepository>.value(value: repo),
        Provider<PhotoService>.value(value: photos),
        ChangeNotifierProvider(
          create: (_) => ProductListController(repo)..load(),
        ),
      ],
      child: const KodModelApp(),
    ),
  );
}
