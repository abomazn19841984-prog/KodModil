import 'dart:math';

/// Helpers for model codes, prices and display formatting.

/// Converts Arabic-Indic (٠-٩) and Persian (۰-۹) digits to ASCII digits.
String normalizeDigits(String input) {
  final buf = StringBuffer();
  for (final rune in input.runes) {
    if (rune >= 0x0660 && rune <= 0x0669) {
      buf.writeCharCode(0x30 + (rune - 0x0660));
    } else if (rune >= 0x06F0 && rune <= 0x06F9) {
      buf.writeCharCode(0x30 + (rune - 0x06F0));
    } else {
      buf.writeCharCode(rune);
    }
  }
  return buf.toString();
}

/// Normalization rule used for duplicate detection (the "code key"):
/// 1) Arabic digits -> ASCII digits, 2) remove ALL whitespace,
/// 3) upper-case Latin letters.
/// So "ab 12", "AB12" and "ab١٢" all collide on purpose.
String normalizeCode(String input) {
  return normalizeDigits(input).replaceAll(RegExp(r'\s+'), '').toUpperCase();
}

/// Parses a price typed by a person. Returns null if empty/invalid.
double? parsePrice(String input) {
  var s = normalizeDigits(input).replaceAll(RegExp(r'\s+'), '');
  if (s.isEmpty) return null;
  s = s.replaceAll('٬', '').replaceAll('٫', '.');
  if (s.contains(',') && s.contains('.')) {
    s = s.replaceAll(',', '');
  } else if (s.contains(',')) {
    if (RegExp(r'^\d{1,3}(,\d{3})+$').hasMatch(s)) {
      s = s.replaceAll(',', '');
    } else {
      s = s.replaceAll(',', '.');
    }
  }
  final v = double.tryParse(s);
  if (v == null || v.isNaN || v.isInfinite) return null;
  return v;
}

String? formatPrice(double? price, String currency) {
  if (price == null) return null;
  final text = price == price.truncateToDouble()
      ? price.toInt().toString()
      : price.toStringAsFixed(2);
  return '$text $currency';
}

String formatDate(DateTime d) {
  final l = d.toLocal();
  String two(int n) => n.toString().padLeft(2, '0');
  return '${l.year}/${two(l.month)}/${two(l.day)} ${two(l.hour)}:${two(l.minute)}';
}

/// Random UUID v4 (never derived from the model code).
String generateId() {
  final r = Random.secure();
  final b = List<int>.generate(16, (_) => r.nextInt(256));
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  String h(int i) => b[i].toRadixString(16).padLeft(2, '0');
  return '${h(0)}${h(1)}${h(2)}${h(3)}-${h(4)}${h(5)}-${h(6)}${h(7)}-'
      '${h(8)}${h(9)}-${h(10)}${h(11)}${h(12)}${h(13)}${h(14)}${h(15)}';
}
