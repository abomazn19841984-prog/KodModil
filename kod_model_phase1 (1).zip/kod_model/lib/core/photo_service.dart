import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

import 'code_utils.dart';

/// Stores photos locally inside the app's private documents folder.
/// The database keeps only the FILE NAME (not an absolute path) so that
/// backup/restore and future sync stay simple.
class PhotoService {
  PhotoService._(this.dir);
  final Directory dir;

  static Future<PhotoService> create() async {
    final base = await getApplicationDocumentsDirectory();
    final d = Directory(p.join(base.path, 'photos'));
    if (!await d.exists()) await d.create(recursive: true);
    return PhotoService._(d);
  }

  File fileFor(String name) => File(p.join(dir.path, name));

  /// Picks a photo; image_picker downsizes (max 1600px) and compresses
  /// (quality 82) it. Returns the stored file name, or null if cancelled.
  Future<String?> pick(ImageSource source) async {
    final x = await ImagePicker().pickImage(
      source: source,
      maxWidth: 1600,
      maxHeight: 1600,
      imageQuality: 82,
    );
    if (x == null) return null;
    final name = '${generateId()}.jpg';
    await File(x.path).copy(p.join(dir.path, name));
    return name;
  }

  Future<void> delete(String name) async {
    try {
      final f = fileFor(name);
      if (await f.exists()) await f.delete();
    } catch (_) {
      // A leftover file is harmless; never crash the UI for it.
    }
  }
}

class PhotoImage extends StatelessWidget {
  const PhotoImage({
    super.key,
    required this.fileName,
    this.width,
    this.height,
    this.fit = BoxFit.cover,
    this.cacheWidth,
  });

  final String fileName;
  final double? width;
  final double? height;
  final BoxFit fit;
  final int? cacheWidth;

  @override
  Widget build(BuildContext context) {
    final file = context.read<PhotoService>().fileFor(fileName);
    return Image.file(
      file,
      width: width,
      height: height,
      fit: fit,
      cacheWidth: cacheWidth,
      errorBuilder: (context, error, stack) => Container(
        width: width,
        height: height,
        color: const Color(0xFFE8EEEE),
        child: const Icon(Icons.broken_image_outlined),
      ),
    );
  }
}
