import 'package:flutter_test/flutter_test.dart';
import 'package:kod_model/core/code_utils.dart';
import 'package:kod_model/features/models/domain/product.dart';

void main() {
  group('normalizeCode', () {
    test('ignores case and spaces', () {
      expect(normalizeCode(' ab 12 '), 'AB12');
      expect(normalizeCode('AB12'), 'AB12');
    });
    test('converts Arabic digits', () {
      expect(normalizeCode('ab١٢'), 'AB12');
      expect(normalizeCode('۱۲۳'), '123');
    });
  });

  group('parsePrice', () {
    test('plain and Arabic digits', () {
      expect(parsePrice('150'), 150);
      expect(parsePrice('١٥٠'), 150);
      expect(parsePrice('99.5'), 99.5);
      expect(parsePrice('99,5'), 99.5);
      expect(parsePrice('99٫5'), 99.5);
    });
    test('thousands separators', () {
      expect(parsePrice('1,000'), 1000);
      expect(parsePrice('1,000.50'), 1000.5);
    });
    test('invalid / empty', () {
      expect(parsePrice(''), isNull);
      expect(parsePrice('abc'), isNull);
    });
  });

  group('ProductValidator', () {
    test('code and name are required', () {
      expect(ProductValidator.code('  '), isNotNull);
      expect(ProductValidator.code('A1'), isNull);
      expect(ProductValidator.name(''), isNotNull);
      expect(ProductValidator.name('بنطلون'), isNull);
    });
    test('price optional but must be a non-negative number', () {
      expect(ProductValidator.price(''), isNull);
      expect(ProductValidator.price('12'), isNull);
      expect(ProductValidator.price('x'), isNotNull);
      expect(ProductValidator.price('-5'), isNotNull);
    });
  });

  test('generateId returns distinct UUID-shaped ids', () {
    final a = generateId();
    final b = generateId();
    expect(a, isNot(b));
    expect(RegExp(r'^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$')
        .hasMatch(a), isTrue);
  });
}
