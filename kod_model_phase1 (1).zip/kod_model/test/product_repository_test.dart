import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:kod_model/features/models/data/app_database.dart';
import 'package:kod_model/features/models/data/product_repository.dart';
import 'package:kod_model/features/models/domain/product.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  late Database db;
  late ProductRepository repo;
  var tick = 0;

  setUp(() async {
    db = await AppDatabase.open(path: inMemoryDatabasePath);
    tick = 0;
    repo = ProductRepository(db,
        clock: () => DateTime.utc(2030, 1, 1).add(Duration(minutes: tick++)));
  });
  tearDown(() async => db.close());

  Product make(String code, {String name = 'موديل'}) =>
      Product.create(code: code, name: name, sizes: ['M', 'L'], price: 100);

  test('create then list/get round-trips all fields', () async {
    final created = await repo.create(make('A1', name: 'قميص'));
    final got = await repo.getById(created.id);
    expect(got, isNotNull);
    expect(got!.code, 'A1');
    expect(got.name, 'قميص');
    expect(got.sizes, ['M', 'L']);
    expect(got.price, 100);
    expect((await repo.list()).length, 1);
  });

  test('duplicate code is rejected (case/space/digit insensitive)', () async {
    await repo.create(make('ab 12'));
    expect(() => repo.create(make('AB12')),
        throwsA(isA<DuplicateCodeException>()));
    expect(() => repo.create(make('ab١٢')),
        throwsA(isA<DuplicateCodeException>()));
    expect((await repo.list()).length, 1);
  });

  test('update bumps version, marks pending, keeps id', () async {
    final c = await repo.create(make('A1'));
    final u = await repo.update(Product.fromMap({
      ...c.toMap(),
      'name': 'اسم جديد',
    }));
    expect(u.id, c.id);
    expect(u.version, 2);
    expect(u.syncState, 'pending');
    expect((await repo.getById(c.id))!.name, 'اسم جديد');
  });

  test('update cannot take another model\'s code', () async {
    await repo.create(make('A1'));
    final b = await repo.create(make('B2'));
    final clash = Product.fromMap({
      ...b.toMap(),
      'code': 'a1',
      'code_key': 'A1',
    });
    expect(() => repo.update(clash), throwsA(isA<DuplicateCodeException>()));
  });

  test('soft delete hides the row, keeps a tombstone, frees the code',
      () async {
    final c = await repo.create(make('A1'));
    await repo.softDelete(c.id);
    expect(await repo.list(), isEmpty);
    expect(await repo.getById(c.id), isNull);
    final tomb = await repo.getById(c.id, includeDeleted: true);
    expect(tomb!.deletedAt, isNotNull);
    expect(tomb.version, 2);
    expect(tomb.syncState, 'pending');
    // the code can be reused after delete
    await repo.create(make('A1'));
    expect((await repo.list()).length, 1);
  });

  test('search by code and by name; sort orders', () async {
    await repo.create(make('X10', name: 'جاكيت'));
    await repo.create(make('B20', name: 'بنطلون'));
    expect((await repo.list(query: 'x1')).map((e) => e.code), ['X10']);
    expect((await repo.list(query: 'بنط')).map((e) => e.code), ['B20']);
    expect((await repo.list(query: '%')), isEmpty); // LIKE chars are escaped
    expect((await repo.list(sort: ProductSort.code)).map((e) => e.code),
        ['B20', 'X10']);
  });

  test('data survives closing and reopening the database', () async {
    final dir = Directory.systemTemp.createTempSync('kod_model_test_');
    final path = p.join(dir.path, 'persist.db');
    try {
      final d1 = await AppDatabase.open(path: path);
      await ProductRepository(d1).create(make('KEEP1'));
      await d1.close();
      final d2 = await AppDatabase.open(path: path);
      final list = await ProductRepository(d2).list();
      await d2.close();
      expect(list.map((e) => e.code), ['KEEP1']);
    } finally {
      dir.deleteSync(recursive: true);
    }
  });
}
