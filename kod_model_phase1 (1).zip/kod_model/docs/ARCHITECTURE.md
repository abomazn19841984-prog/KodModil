# Architecture (Phase 1)
- State: provider + ChangeNotifier (ProductListController). Repository pattern over sqflite.
- Layers: features/models/{domain,data,presentation}; core/ for utilities.
- Table `products`: id (UUID v4), owner_uid, code, code_key, name, description, price, currency,
  fabric, sizes(JSON), colors(JSON), extra_details, main_photo, extra_photos(JSON),
  created_at/updated_at/deleted_at (UTC epoch ms), version, sync_state(pending|synced|failed).
- Uniqueness: partial UNIQUE index on code_key WHERE deleted_at IS NULL.
- Delete = tombstone (deleted_at set), kept for Phase 3 sync.
- Photos: file names only; files live in <documents>/photos.
- Migrations: bump AppDatabase.schemaVersion + stepwise onUpgrade.
