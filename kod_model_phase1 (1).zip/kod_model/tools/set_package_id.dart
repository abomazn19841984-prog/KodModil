// Run ONCE from the project folder, after `flutter create`:
//   dart run tools/set_package_id.dart
// Changes the Android package/applicationId from the one `flutter create`
// generates (com.kodmodel.kod_model) to the approved one (com.kodmodel.app)
// and sets the Arabic app name. Safe to run twice (it does nothing the 2nd time).
import 'dart:io';

const oldId = 'com.kodmodel.kod_model';
const newId = 'com.kodmodel.app';
const appLabel = 'تكويد الموديلات';

void main() {
  if (!Directory('android/app').existsSync()) {
    stderr.writeln('شغّل الأمر من جوه فولدر المشروع (اللي فيه فولدر android).');
    exit(1);
  }
  var changed = 0;

  for (final name in ['build.gradle.kts', 'build.gradle']) {
    final f = File('android/app/$name');
    if (f.existsSync()) {
      final s = f.readAsStringSync();
      if (s.contains(oldId)) {
        f.writeAsStringSync(s.replaceAll(oldId, newId));
        changed++;
        print('تم تعديل android/app/$name');
      }
    }
  }

  final manifest = File('android/app/src/main/AndroidManifest.xml');
  if (manifest.existsSync()) {
    final s = manifest.readAsStringSync();
    final re = RegExp(r'android:label="[^"]*"');
    if (re.hasMatch(s) && !s.contains('android:label="$appLabel"')) {
      manifest.writeAsStringSync(
          s.replaceFirst(re, 'android:label="$appLabel"'));
      changed++;
      print('تم تعديل اسم التطبيق في AndroidManifest.xml');
    }
  }

  final oldDir = Directory('android/app/src/main/kotlin/com/kodmodel/kod_model');
  final newDir = Directory('android/app/src/main/kotlin/com/kodmodel/app');
  final oldFile = File('${oldDir.path}/MainActivity.kt');
  if (oldFile.existsSync()) {
    newDir.createSync(recursive: true);
    File('${newDir.path}/MainActivity.kt')
        .writeAsStringSync(oldFile.readAsStringSync().replaceAll(oldId, newId));
    oldFile.deleteSync();
    if (oldDir.listSync().isEmpty) oldDir.deleteSync();
    changed++;
    print('تم نقل MainActivity.kt');
  }

  print(changed == 0
      ? 'مفيش حاجة اتغيّرت (يمكن اتعمل قبل كده).'
      : 'خلص. راجع الناتج بالأمر المكتوب في README.');
}
